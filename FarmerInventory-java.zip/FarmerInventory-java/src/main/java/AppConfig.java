import maher.dermot.repository.HerdRepository;
import maher.dermot.repository.HerdRepositoryImpl;
import maher.dermot.service.HerdService;
import maher.dermot.service.HerdServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"maher.dermot"})
public class AppConfig {

    /*
    @Bean(name="herdService")
    public HerdService getHerdService(){
        HerdServiceImpl service = new HerdServiceImpl();
        service.setHerdRepository(getHerdRepository());
        return service;
    }

    @Bean(name="herdRepository")
    public HerdRepository getHerdRepository(){
        return new HerdRepositoryImpl();
    }

     */
}
