package maher.dermot.service;

import maher.dermot.model.Herd;
import maher.dermot.repository.HerdRepository;
import maher.dermot.repository.HerdRepositoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("herdService")
public class HerdServiceImpl implements HerdService {

    private HerdRepository herdRepository;

    @Override
    public List<Herd> findAll(){
        return herdRepository.findAll();
    }

    @Autowired
    public void setHerdRepository(HerdRepository herdRepository) {
        this.herdRepository = herdRepository;
    }
}
