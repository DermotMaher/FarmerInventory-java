package maher.dermot.service;

import maher.dermot.model.Herd;

import java.util.List;

public interface HerdService {
    List<Herd> findAll();
}
