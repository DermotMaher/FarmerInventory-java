package maher.dermot.model;

import java.util.List;

public class Farmer {

    public Farmer(){};

    private String firstName;
    private String lastName;
    private List<Herd> herdList;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<Herd> getHerdList() {
        return herdList;
    }

    public void setHerdList(List<Herd> herdList) {
        this.herdList = herdList;
    }

}
