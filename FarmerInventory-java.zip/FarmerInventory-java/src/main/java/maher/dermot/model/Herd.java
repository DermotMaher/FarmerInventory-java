package maher.dermot.model;

import java.util.ArrayList;
import java.util.List;

public class Herd {

    private String herdNumber;
    private Integer quantity;
    private List<String> schemes = new ArrayList<>();

    public List<String> getSchemes() {
        return schemes;
    }

    public void setSchemes(String scheme) {
        schemes.add(scheme);
    }
    public void setSchemes(List<String> schemes) {
        this.schemes = schemes;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getHerdNumber() {
        return herdNumber;
    }

    public void setHerdNumber(String herdNumber) {
        this.herdNumber = herdNumber;
    }
}
