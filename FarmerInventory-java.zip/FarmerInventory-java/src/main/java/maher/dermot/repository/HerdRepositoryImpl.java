package maher.dermot.repository;

import maher.dermot.model.Herd;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("herdRepositoryOld")
public class HerdRepositoryImpl implements HerdRepository {


    @Override
    public List<Herd> findAll(){
        List<Herd> herds = new ArrayList<Herd>();

        Herd herd = new Herd();

        herd.setHerdNumber("A1234567");
        herd.setQuantity(10);
        herd.setSchemes("SMR1");

        herds.add(herd);
        return herds;
    }
}
