package maher.dermot.repository;

import maher.dermot.model.Herd;

import java.util.List;

public interface HerdRepository {
    List<Herd> findAll();
}
