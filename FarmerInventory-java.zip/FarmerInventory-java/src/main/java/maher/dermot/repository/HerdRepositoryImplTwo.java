package maher.dermot.repository;

import maher.dermot.model.Herd;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("herdRepository")
public class HerdRepositoryImplTwo implements HerdRepository{

    @Override
    public List<Herd> findAll(){
        List<Herd> herds = new ArrayList<Herd>();

        Herd herd = new Herd();

        herd.setHerdNumber("Q0987654");
        herd.setQuantity(6);

        List<String> schemes = new ArrayList<>();
        schemes.add("SMR7");
        schemes.add("BEAM");

        herd.setSchemes(schemes);

        herds.add(herd);
        return herds;
    }
}
