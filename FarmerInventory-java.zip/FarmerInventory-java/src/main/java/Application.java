import maher.dermot.model.Herd;
import maher.dermot.service.HerdService;
import maher.dermot.service.HerdServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {

    public static void main(String[] args){

        ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);

        HerdService service = appContext.getBean("herdService", HerdService.class);
        Herd exampleHerd = service.findAll().get(0);
        System.out.println("Herd Number " + exampleHerd.getHerdNumber());
        System.out.println("is associated with the following schemes: " + exampleHerd.getSchemes());
    }
}
