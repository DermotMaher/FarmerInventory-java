package maher.dermot.repository;

import static org.junit.jupiter.api.Assertions.*;

class HerdRepositoryImplShould {

    @org.junit.jupiter.api.Test
    void findAll() {
    }
}